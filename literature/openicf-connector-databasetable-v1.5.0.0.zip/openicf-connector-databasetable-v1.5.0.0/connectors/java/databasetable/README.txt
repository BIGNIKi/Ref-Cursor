Changelog:
Version 1.1:
 When datasource is configured, added closing connections functionality  
Version 1.0:
 Initial version
 

Supported JDBC drivers:
=======================
- MySQL Connector/J 5.1.6
- Microsoft SQL Server 2005 JDBC Driver 1.2
- Oracle Database 10g Release 2 (10.2.0.2) JDBC Driver
- Apache Derby 10.4

Unsupported JDBC drivers:
=========================
- MySQL Connector/J 3.0.17-ga
- IBM Data Server Driver for JDBC and SQLJ v 3.50.152 (ResultSetMetaData#isWritable returns false on all columns)
