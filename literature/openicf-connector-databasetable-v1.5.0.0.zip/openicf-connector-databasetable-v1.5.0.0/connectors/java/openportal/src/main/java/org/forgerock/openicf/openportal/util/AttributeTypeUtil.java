/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.forgerock.openicf.openportal.util;

/**
 *
 * @author admin
 */
public class AttributeTypeUtil {

}
