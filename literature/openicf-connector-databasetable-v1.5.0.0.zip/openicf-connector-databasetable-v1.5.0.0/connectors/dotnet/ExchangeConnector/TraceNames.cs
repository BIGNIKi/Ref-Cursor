﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Org.IdentityConnectors.Exchange {
    class TraceNames {
        public static string DEFAULT = "ExchangeConnector";
        public static string API = "ExchangeConnector.Api";
        public static string POWERSHELL = "ExchangeConnector.PowerShell";
        public static string ACCOUNT_HANDLER = "ExchangeConnector.AccountHandler";
    }
}
